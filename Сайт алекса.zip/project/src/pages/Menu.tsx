import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Category, Dish } from '../types';
import { ShoppingCart } from 'lucide-react';

const Menu = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCategories();
    fetchDishes();
  }, []);

  const fetchCategories = async () => {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error fetching categories:', error);
      return;
    }
    
    setCategories(data);
    if (data.length > 0 && !selectedCategory) {
      setSelectedCategory(data[0].id);
    }
  };

  const fetchDishes = async () => {
    const { data, error } = await supabase
      .from('dishes')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error fetching dishes:', error);
      return;
    }
    
    setDishes(data);
    setLoading(false);
  };

  const filteredDishes = selectedCategory
    ? dishes.filter((dish) => dish.category_id === selectedCategory)
    : dishes;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-8">Меню</h1>
      
      {/* Categories */}
      <div className="flex overflow-x-auto pb-4 mb-8 gap-4">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-colors ${
              selectedCategory === category.id
                ? 'bg-red-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* Dishes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredDishes.map((dish) => (
          <div
            key={dish.id}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
          >
            {dish.image_url && (
              <img
                src={dish.image_url}
                alt={dish.name}
                className="w-full h-48 object-cover"
              />
            )}
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{dish.name}</h3>
              {dish.description && (
                <p className="text-gray-600 mb-4">{dish.description}</p>
              )}
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-red-600">
                  {dish.price.toLocaleString('ru-RU')} ₽
                </span>
                <button
                  className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors"
                  onClick={() => {
                    // TODO: Implement add to cart functionality
                    console.log('Add to cart:', dish);
                  }}
                >
                  <ShoppingCart className="w-5 h-5" />
                  В корзину
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredDishes.length === 0 && (
        <div className="grid grid-cols-5 gap-4 p-4">
          <p className="text-gray-500 text-lg">
            
          </p>
        </div>
      )}
    </div>
  );
};

export default Menu;