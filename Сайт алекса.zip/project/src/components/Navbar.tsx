import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, User, Menu as MenuIcon } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="text-2xl font-bold text-gray-900">
               
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <Link
                to="/"
                className="text-gray-900 inline-flex items-center px-1 pt-1 text-sm font-medium"
              >
                Главная
              </Link>
              <Link
                to="/menu"
                className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 text-sm font-medium"
              >
                Меню
              </Link>
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-4">
            <Link
              to="/cart"
              className="p-2 rounded-full text-gray-500 hover:text-gray-900"
            >
              <ShoppingCart className="h-6 w-6" />
            </Link>
            <Link
              to="/profile"
              className="p-2 rounded-full text-gray-500 hover:text-gray-900"
            >
              <User className="h-6 w-6" />
            </Link>
          </div>
          <div className="flex items-center sm:hidden">
            <button className="p-2 rounded-md text-gray-500 hover:text-gray-900">
              <MenuIcon className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;